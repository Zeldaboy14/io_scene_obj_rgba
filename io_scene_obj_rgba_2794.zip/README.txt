THIS IS THE 2.79.4 VERSION!!!!

Expects vertices in the format:
v x y z r g b a

Where r g b a are values 0 <= n <= 255


